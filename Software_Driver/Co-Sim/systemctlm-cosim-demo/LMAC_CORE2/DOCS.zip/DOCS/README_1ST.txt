
Dec 1, 2018

LeWiz Communications, Inc.

Although the documents may contain information about LEWIZ LMAC CORE1, CORE2, and CORE3
This release is only intended for LMAC CORE2 (10G/5G/2.5G/1G) only.
LMAC CORE1 has been released to Github previously
CORE3 is for potential future releases and users should not rely on CORE3 information.