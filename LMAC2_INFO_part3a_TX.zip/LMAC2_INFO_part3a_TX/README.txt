
Extract and put in the TEST folder of LMAC2_INFO