
RX example test cases
See LMAC2_INFO_part1: LMAC TestBench Doc and RX_TEST Excel spreadsheet for more info.